> If you move this folder, you need to adjust `CLM_USRDAT_DIR` in `user_mods/shell_commands` accordingly.
